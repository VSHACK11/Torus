BEFORE READING OR PLAYING DOWNLOAD PYTHON ON YOUR PC!

This is a basic game

Every input is given by the cmd window.
all prompts, for now, are the color of your planet(s).
The colored path of the planted signals if the planet is habbital or not to life;
this is random.
Talid inputs for your planet color are the following;
Hexadecimal, plain text, and rgb values in the form of r, g, b values.
The path the planet is on will show if the planet has life or not;
the green path shows there is life, while the red shows there is not.

That is it more coming soon!