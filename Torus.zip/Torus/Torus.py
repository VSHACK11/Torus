import random
import turtle
wn = turtle.Screen()
wn.bgpic("torus background.png")
wn.title("Torus")
scr = turtle.Turtle()
scr.pensize(2)
scr.speed(10.40)

#setup repeatables
    #Variables
bgcolor = "black"
pncolor = "white"
font = ("Arial", 20, "normal")
slnm = wn.textinput("Solar system name", "Name:")
x = random.randrange(1, 3, 1)
if x > 1:
    lhrn = "red"
else: 
    lhrn = "green"

    #functions
def makeRing(r, o, c, cb):
    scr.pencolor(bgcolor)
    scr.goto(0, o)
    scr.pencolor(c)
    scr.circle(r)
    scr.pencolor(bgcolor)
    scr.goto(45, o)
    scr.pencolor(cb)
    scr.circle(15)
     
def pnoff():
    scr.pencolor(bgcolor)
def pnon(color):
    scr.pencolor(color)
def solarname():
    pnoff()
    scr.goto(0, 250)
    pnon("white")
    scr.write(slnm, font=font, align="left")

solarname()
pnoff()
scr.goto(-25, 0)
pnon("yellow")
scr.circle(35)
print("planet 1 color:")
makeRing(100, -100, "red", input())
print("planet 2 color:")
makeRing(150, -150, lhrn, input())
print("planet 3 color:")
makeRing(200, -200, lhrn, input())

print(slnm)
#FINISHED

turtle.done()