import random
#setup repeatables
    #Variables
bgcolor = "black"
pncolor = "white"
x = random.randint(1, 2)
if x == 2:
    lhrn = "red"
else: 
    lhrn = "green"

    #functions
def makeRing(r, o, c, cb):
    scr.pencolor(bgcolor)
    scr.goto(0, o)
    scr.pencolor(c)
    scr.circle(r)
    scr.pencolor(bgcolor)
    scr.goto(45, o)
    scr.pencolor(cb)
    scr.circle(15)
    
def pnoff():
    scr.pencolor(bgcolor)
def pnon(color):
    scr.pencolor(color)
    

#setup screen
import turtle
wn = turtle.Screen()
wn.bgpic("torus background.png")
wn.title("Torus")
scr = turtle.Turtle()
scr.pensize(2)
scr.speed(10.40)

#make System
pnoff()
scr.goto(-25, 0)
pnon("yellow")
scr.circle(35)
print("planet 1 color:")
makeRing(100, -100, "red", input())
print("planet 2 color:")
makeRing(150, -150, lhrn, input())
print("planet 3 color:")
makeRing(200, -200, lhrn, input())

#FINISHED

turtle.done()